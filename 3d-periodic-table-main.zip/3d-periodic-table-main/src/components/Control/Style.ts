type Style = {
  color: string;
  opacity?: number;
  metalness?: number;
  roughness?: number;
};

export default Style;
