import jsonData from "./data/data.json";
import AtomInfo from "./types/AtomInfo";

const data: AtomInfo[] = jsonData as AtomInfo[];
export default data;
